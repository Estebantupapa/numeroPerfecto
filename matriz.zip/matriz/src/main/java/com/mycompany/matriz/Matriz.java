/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matriz;

import java.util.Random;

/**
 *
 * @author SCIS3-10
 */
public class Matriz {

    public static void main(String[] args) {
        int m = 421;
        int [][] matriz = new int[m][m];
        
        Random random = new Random();
        long inicio = System.currentTimeMillis();
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                 matriz[i][j] = random.nextInt(100);
            }
        }
         
        System.out.println("matriz "+ m+ " x "+ m +":");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(matriz[i][j] + "");
            }
            System.out.println();
        }
        long fin = System.currentTimeMillis();
        
        long tiempo = (fin - inicio);
  
        System.out.println("Tiempo de ejecución: " + tiempo + " milisegundos.");
    }
    
}
